﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.IO;
using Microsoft.Office.Interop;
using Excel = Microsoft.Office.Interop.Excel;
using Microsoft.Office.Interop.Excel;
using System.Windows.Forms.DataVisualization.Charting;

namespace SD_GUI
{
    public partial class Power : Form
    {
        public Power()
        {
            InitializeComponent();
            FormBorderStyle = FormBorderStyle.None;
            WindowState = FormWindowState.Maximized;
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void HomeButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage h = new HomePage();
            h.Show();
        }

        private void SettingsButton_Click(object sender, EventArgs e)
        {
            Settings f = new Settings();
            f.Show();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e) //Voltage Form
        {
            Voltage v = new Voltage();
            v.Show();
        }

        private void button4_Click(object sender, EventArgs e) //Current Form
        {
            Current c = new Current();
            c.Show();
        }

        private void button5_Click(object sender, EventArgs e) //Home
        {
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e) //Actual Settings button
        {
            Settings f = new Settings();
            f.Show();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            
                _Application importExcelToDataGridViewApp1;
                _Workbook importExcelToDataGridViewWorkbook;
                _Worksheet importExcelToDataGridViewWorksheet;
                Range importExcelToDataGridViewRange;

                try
                {
                    importExcelToDataGridViewApp1 = new Microsoft.Office.Interop.Excel.Application();
                    OpenFileDialog importExcelToDataGridViewFileDialog = new OpenFileDialog();
                    importExcelToDataGridViewFileDialog.InitialDirectory = "C:/Desktop/Data Hub Project Files";
                    importExcelToDataGridViewFileDialog.Filter = "Excel Files | *.xls; *.xlsx; *.xlsm; *.csv";
                    if (importExcelToDataGridViewFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        importExcelToDataGridViewWorkbook = importExcelToDataGridViewApp1.Workbooks.Open(importExcelToDataGridViewFileDialog.FileName);
                        importExcelToDataGridViewWorksheet = importExcelToDataGridViewWorkbook.ActiveSheet;
                        importExcelToDataGridViewRange = importExcelToDataGridViewWorksheet.UsedRange;

                        for (int excelWorksheetRowIndex = 2; excelWorksheetRowIndex <= importExcelToDataGridViewRange.Rows.Count; excelWorksheetRowIndex++)
                        {
                            dataGridView1.Rows.Add(importExcelToDataGridViewWorksheet.Cells[excelWorksheetRowIndex, 9].Value, importExcelToDataGridViewWorksheet.Cells[excelWorksheetRowIndex, 6].Value, null); //6
                            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                        }
                    }
                }
                catch (Exception)
                {

                }
                List<string> TimeList = new List<string>();
                List<float> PowerList = new List<float>();

                for (int i = 0; i < dataGridView1.RowCount - 1; i++)
                {
                    string timeTmp = dataGridView1.Rows[i + 1].Cells[0].Value.ToString();
                    float powerTmp = float.Parse(dataGridView1.Rows[i + 1].Cells[1].Value.ToString());

                    TimeList.Add(timeTmp);
                    PowerList.Add(powerTmp);
                    chart1.Series["Power"].Points.AddXY(TimeList[i], PowerList[i]);
                }            

        }

        private void button7_Click(object sender, EventArgs e) //export
        {
            /*string mySheet = @"C:\Dumpster\testcsv.csv";
            var excelApp = new Excel.Application();
            excelApp.Visible = true;
            Excel.Workbooks powers = excelApp.Workbooks;
            Excel.Workbook sheet = powers.Open(mySheet); */
            Excel.Application xlApp;
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;

            xlApp = new Excel.Application();
            xlWorkBook = xlApp.Workbooks.Add(misValue);
            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);
            int i = 0;
            int j = 0;

            for (i = 0; i <= dataGridView1.RowCount - 1; i++)
            {
                for (j = 0; j <= dataGridView1.ColumnCount - 1; j++)
                {
                    DataGridViewCell cell = dataGridView1[j, i];
                    xlWorkSheet.Cells[i + 1, j + 1] = cell.Value;
                }
            }

            xlWorkBook.SaveAs("Power Values.xls", Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
            xlWorkBook.Close(true, misValue, misValue);
            xlApp.Quit();

            releaseObject(xlWorkSheet);
            releaseObject(xlWorkBook);
            releaseObject(xlApp);

            MessageBox.Show("Excel file created , you can find the file C:/Documents/Power Values.xls");
        }

        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }        
    }

        private void button8_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
