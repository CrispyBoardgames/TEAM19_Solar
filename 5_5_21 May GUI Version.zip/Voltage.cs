﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;
using Microsoft.Office.Interop.Excel;

namespace SD_GUI
{
    public partial class Voltage : Form
    {
        public Voltage()
        {
            InitializeComponent();
            FormBorderStyle = FormBorderStyle.None;
            WindowState = FormWindowState.Maximized;
        }

        private void BatteryPack1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e) //Home button 
        {
            HomePage h = new HomePage();
            h.Show();
            this.Hide();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void SettingsButton_Click(object sender, EventArgs e)
        {
            Settings s = new Settings();
            s.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Power p = new Power();
            p.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Current c = new Current();
            c.Show();
        }

        private void ExportButton_Click(object sender, EventArgs e)
        {
            //string mySheet = @"C:/Desktop/Data Hub Project Files/Test2.csv";
            //var excelApp = new Excel.Application();
            //excelApp.Visible = true;
            //Excel.Workbooks voltages = excelApp.Workbooks;
            //Excel.Workbook sheet = voltages.Open(mySheet);

            Excel.Application xlApp;
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;

            xlApp = new Excel.Application();
            xlWorkBook = xlApp.Workbooks.Add(misValue);
            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);
            int i = 0;
            int j = 0;

            for (i = 0; i <= dataGridView1.RowCount - 1; i++)
            {
                for (j = 0; j <= dataGridView1.ColumnCount - 1; j++)
                {
                    DataGridViewCell cell = dataGridView1[j, i];
                    xlWorkSheet.Cells[i + 1, j + 1] = cell.Value;
                }
            }

            xlWorkBook.SaveAs("Voltage Values.xls", Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
            xlWorkBook.Close(true, misValue, misValue);
            xlApp.Quit();

            releaseObject(xlWorkSheet);
            releaseObject(xlWorkBook);
            releaseObject(xlApp);

            MessageBox.Show("Excel file created , you can find the file C:/Documents/Voltage Values.xls");
        }

        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }

    private void PrintButton_Click(object sender, EventArgs e) //Back btn
        {
            this.Hide();
        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            _Application importExcelToDataGridViewApp1;
            _Workbook importExcelToDataGridViewWorkbook;
            _Worksheet importExcelToDataGridViewWorksheet;
            Range importExcelToDataGridViewRange;

            try
            {
                importExcelToDataGridViewApp1 = new Microsoft.Office.Interop.Excel.Application();
                OpenFileDialog importExcelToDataGridViewFileDialog = new OpenFileDialog();
                importExcelToDataGridViewFileDialog.InitialDirectory = "C:/Desktop/Data Hub Project Files";
                importExcelToDataGridViewFileDialog.Filter = "Excel Files | *.xls; *.xlsx; *.xlsm; *.csv";
                if (importExcelToDataGridViewFileDialog.ShowDialog() == DialogResult.OK)
                {
                    importExcelToDataGridViewWorkbook = importExcelToDataGridViewApp1.Workbooks.Open(importExcelToDataGridViewFileDialog.FileName);
                    importExcelToDataGridViewWorksheet = importExcelToDataGridViewWorkbook.ActiveSheet;
                    importExcelToDataGridViewRange = importExcelToDataGridViewWorksheet.UsedRange;

                    for (int excelWorksheetRowIndex = 2; excelWorksheetRowIndex <= importExcelToDataGridViewRange.Rows.Count; excelWorksheetRowIndex++)
                    {
                        dataGridView1.Rows.Add(importExcelToDataGridViewWorksheet.Cells[excelWorksheetRowIndex, 9].Value, importExcelToDataGridViewWorksheet.Cells[excelWorksheetRowIndex, 4].Value, null); //Inverter                        
                        dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                    }
                    for (int excelWorksheetRowIndex = 2; excelWorksheetRowIndex <= importExcelToDataGridViewRange.Rows.Count; excelWorksheetRowIndex++)
                    {
                        dataGridView2.Rows.Add(importExcelToDataGridViewWorksheet.Cells[excelWorksheetRowIndex, 9].Value, importExcelToDataGridViewWorksheet.Cells[excelWorksheetRowIndex, 3].Value, null); //Panel
                        dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;                  
                    }
                    for (int excelWorksheetRowIndex = 2; excelWorksheetRowIndex <= importExcelToDataGridViewRange.Rows.Count; excelWorksheetRowIndex++)
                    {
                        dataGridView3.Rows.Add(importExcelToDataGridViewWorksheet.Cells[excelWorksheetRowIndex, 9].Value, importExcelToDataGridViewWorksheet.Cells[excelWorksheetRowIndex, 2].Value, null); //Battery
                        dataGridView3.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                    }
                }
            }
            catch (Exception)
            {

            }
            List<string> TimeList = new List<string>();
            List<float> VoltageList = new List<float>();
            List<string> TimeList1 = new List<string>();
            List<float> VoltageList1 = new List<float>();
            List<string> TimeList2 = new List<string>();
            List<float> VoltageList2 = new List<float>();


            for (int i = 0; i < dataGridView1.RowCount - 1; i++)
            {
                string timeTmp = dataGridView1.Rows[i + 1].Cells[0].Value.ToString();
                float xix = float.Parse(timeTmp);
                if (i == 0)
                    {
                    TimeSpan time = TimeSpan.FromSeconds(xix);
                    //MessageBox.Show(time);
                   // Console.WriteLine(time.ToString("hh':'mm':'ss"));
                }
                float voltageTmp = float.Parse(dataGridView1.Rows[i + 1].Cells[1].Value.ToString());
                //dataGridView1.Columns[0].DefaultCellStyle.Format = "hh:mm:ss";

                TimeList.Add(timeTmp);
                VoltageList.Add(voltageTmp);
                chart1.Series["Voltage"].Points.AddXY(TimeList[i], VoltageList[i]);
                chart5.Series["Buck Converter Output"].Points.AddXY(TimeList[i], VoltageList[i]);
            }
            for (int i = 0; i < dataGridView2.RowCount - 1; i++)
            {
                string timeTmp1 = dataGridView2.Rows[i + 1].Cells[0].Value.ToString();
                float voltageTmp1 = float.Parse(dataGridView2.Rows[i + 1].Cells[1].Value.ToString());

                TimeList1.Add(timeTmp1);
                VoltageList1.Add(voltageTmp1);
                chart3.Series["Voltage"].Points.AddXY(TimeList1[i], VoltageList1[i]);
                //chart3.AxisX.Title = "Voltage (V)";
                chart5.Series["PV Panel Output"].Points.AddXY(TimeList1[i], VoltageList1[i]);
            }
            for (int i = 0; i < dataGridView3.RowCount - 1; i++)
            {
                string timeTmp2 = dataGridView3.Rows[i + 1].Cells[0].Value.ToString();
                float voltageTmp2 = float.Parse(dataGridView3.Rows[i + 1].Cells[1].Value.ToString());

                TimeList2.Add(timeTmp2);
                VoltageList2.Add(voltageTmp2);
                chart4.Series["Voltage"].Points.AddXY(TimeList2[i], VoltageList2[i]);
                chart5.Series["Load Output"].Points.AddXY(TimeList2[i], VoltageList2[i]);
            }
            
            /*
            try
            {
                importExcelToDataGridViewApp1 = new Microsoft.Office.Interop.Excel.Application();
                OpenFileDialog importExcelToDataGridViewFileDialog = new OpenFileDialog();
                importExcelToDataGridViewFileDialog.InitialDirectory = "C:/Desktop/Data Hub Project Files";
                importExcelToDataGridViewFileDialog.Filter = "Excel Files | *.xls; *.xlsx; *.xlsm; *.csv";
                if (importExcelToDataGridViewFileDialog.ShowDialog() == DialogResult.OK)
                {
                    importExcelToDataGridViewWorkbook = importExcelToDataGridViewApp1.Workbooks.Open(importExcelToDataGridViewFileDialog.FileName);
                    importExcelToDataGridViewWorksheet = importExcelToDataGridViewWorkbook.ActiveSheet;
                    importExcelToDataGridViewRange = importExcelToDataGridViewWorksheet.UsedRange;

                    for (int excelWorksheetRowIndex = 2; excelWorksheetRowIndex <= importExcelToDataGridViewRange.Rows.Count; excelWorksheetRowIndex++)
                    {
                        dataGridView2.Rows.Add(importExcelToDataGridViewWorksheet.Cells[excelWorksheetRowIndex, 1].Value, importExcelToDataGridViewWorksheet.Cells[excelWorksheetRowIndex, 4].Value, null);
                        dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                    }
                }
            }
            catch (Exception)
            {

            }*/

            //for (int i = 0; i < dataGridView1.RowCount - 1; i++)
            //{
            //    chart1.Series["Voltage"].Points.AddXY(TimeList[i], VoltageList[i]);
            //}
        }
    }
    
}
