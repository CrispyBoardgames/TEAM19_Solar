﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SD_GUI
{
    public partial class HomePage : Form
    {
        public HomePage()
        {
            InitializeComponent();
            FormBorderStyle = FormBorderStyle.None;
            WindowState = FormWindowState.Maximized;
            DataTable dt = new DataTable();
            dt.Columns.Add("Data Type", typeof(string));
            dt.Rows.Add("Voltage Levels");
            dt.Rows.Add("Current Levels");
            dt.Rows.Add("Power Flow");
            DataRow dr = dt.NewRow();
            dr["Data Type"] = "Choose your data type";
            dt.Rows.InsertAt(dr, 0);
            comboBox1.DataSource = dt;
            comboBox1.DisplayMember = "Data Type";
            comboBox1.ValueMember = "Data Type";

        }

        private void HomePage_Load(object sender, EventArgs e)
        {
            
        }

       
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedValue.ToString() == "Voltage Levels")
            {
                Voltage f = new Voltage();
                f.Show();
            }
            else if (comboBox1.SelectedValue.ToString() == "Current Levels")
            {
                Current f = new Current();
                f.Show();
            }
            else if (comboBox1.SelectedValue.ToString() == "Power Flow")
            {
                Power f = new Power();
                f.Show();
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e) //exit
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to exit the Data Hub?", "Confirm", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                Application.Exit();
            }
            else if (dialogResult == DialogResult.No)
            {

            }
        }
    }
    
}
